<?php

namespace LaravelMatrix\Http\Controllers;
use vermotr\Math\Matrix;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

class MatrixController extends Controller
{

	public function show(Request $req)
	{

		$matrix1=$req->input('mat1_array');
		$matrix2=$req->input('mat2_array');

		//print_r($matrix1);
		//print_r($matrix2);
		 $row1=$req->input('mat1_row');
		// echo $row1;
		 $col2=$req->input('mat2_col');
		 //echo $col2;
			$mat1=json_decode($matrix1);

			$mat2=json_decode($matrix2);

foreach($mat1 as $key => $value){
    $mat1data[] = array_flatten($mat1[$key]);
}
		//print_r($mat1data);
		

		foreach($mat1 as $key => $value){
    $mat2data[] = array_flatten($mat1[$key]);
}
		//print_r($mat2data);
for ($i = 0; $i < $row1; $i++) 
    { 
        for ($j = 0; $j < $col2; $j++) 
        { 
            $res[$i][$j] = 0; 
            for ($k = 0; $k <count($mat1data); $k++) 
                $res[$i][$j] += $mat1data[$i][$k] *  
                                $mat2data[$k][$j]; 
        } 
    } 

  



  


echo ("Result matrix is: <br>"); 
for ($i = 0; $i < $row1; $i++) 
{ 
    for ($j = 0; $j < $col2; $j++) 
    { 
        echo ($res[$i][$j]); 
        echo(" "); 
    } 
    echo '<br>'; 
} 
	
	}

}
